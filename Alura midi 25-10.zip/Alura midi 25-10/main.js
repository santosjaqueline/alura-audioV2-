function tocaSom(){
    document.querySelector('#som_tecla_pom').play();
}
function tocaSom(){
    document.querySelector('#som_tecla_clap').play();
}
function tocaSom(){
    document.querySelector('#som_tecla_tim').play();
}
function tocaSom(){
    document.querySelector('#som_tecla_puff').play();
}
function tocaSom(){
    document.querySelector('#som_tecla_splash').play();
}
function tocaSom(){
    document.querySelector('#som_tecla_toim').play();
}
function tocaSom(){
    document.querySelector('#som_tecla_psh').play();
}
function tocaSom(){
    document.querySelector('#som_tecla_tic').play();
}
function tocaSom(){
    document.querySelector('#som_tecla_tom').play();
}